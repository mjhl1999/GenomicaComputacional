#!/bin/bash
echo "Después de la Parte I. necesito un descanso de exactamente 30 segundos."
sleep 300s
echo "Ya puedo continuar!"
